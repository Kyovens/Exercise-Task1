const sqlite = require('sqlite3')
const db = new sqlite.Database('mydata.db');

db.run('CREATE TABLE IF NOT EXISTS kejadian (deskirpsi TEXT, pelaku TEXT, umur INT)')

db.all('SELECT * FROM kejadian',(err, rows)=> {
    if (err) {
        console.log('oops ada masalah')
    }else {
        console.log(rows)
    }
})