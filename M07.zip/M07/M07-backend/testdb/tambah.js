const sqlite = require('sqlite3')
const db = new sqlite.Database('mydata.db');

db.run('CREATE TABLE IF NOT EXISTS kejadian (deskirpsi TEXT, pelaku TEXT, umur INT)')
db.run('INSERT INTO kejadian Values ("Hujan Deras","Masyarakat",20)')
db.run('INSERT INTO kejadian Values ("Banjir Besar","IF-C",20)')

const deskripsi = process.argv[2]
const pelaku = process.argv[3]
const umur = process.argv[4]

db.run(`INSERT INTO kejadian VALUES ("${deskripsi}", "${pelaku}", ${umur})`)

