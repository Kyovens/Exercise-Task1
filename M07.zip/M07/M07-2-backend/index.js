const express = require('express')
const app = express()
const cors = require('cors')
app.use(cors())

const sqlite = require("sqlite3")
const db = new sqlite.Database('mydata.db');
db.run("CREATE TABLE IF NOT EXISTS kejadian(deskripsi TEXT, pelaku TEXT, umur INT)")

app.get("/tampil", (req, res)=> {
    console.log('Ada yang minta data')
})
app.get("/tampil", (req,res)=> {
    console.log('Ada yang minta data')
    db.all('SELECT * FROM kejadian', (err, rows)=> {
        if(err){
            res.status(500)
            res.send('Oops ada masalah')
        }else{
            res.send(rows)
        }
    })
})

app.post("/tambah", (req, res)=>{
    console.log('ada yang ngepost')
    console.log(req.body)
    db.run(`INSERT INTO kejadian VALUES ("${req.body.deskripsi}", "${req.body.pelaku}", ${req.body.umur})`)
    res.end()
})

app.listen(3000,()=>{
    console.log('server jalan')
})
app.listen(3000)